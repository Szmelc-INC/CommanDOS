      PID    PPID    PGID     WINPID   TTY         UID    STIME COMMAND
     1121       1    1121       5456  cons0     197609 06:10:59 /usr/bin/ps
