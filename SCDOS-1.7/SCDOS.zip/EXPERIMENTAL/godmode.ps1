# Spawn GodMode Folder
echo "Create GodMode Settings Folder on Desktop" 
Start-Sleep -Seconds 1
clear
Start-Sleep -Seconds 1
Write-Host "`n=========================================="
Write-Host "||    [Szmelc-CommanDOS_x64] [ps1]      ||"
Write-Host "=========================================="
Write-Host "||     [GOD-MODE DEV CONFIG 'Folder']  ]||"
Write-Host "|| [Szmelc.INC - SilverX / POWER-TOOLS  ||"
Write-Host "=========================================="
Start-Sleep -Seconds 1

New-Item -ItemType Directory -Path "$env:userprofile\Desktop\GodMode.{ed7ba470-8e54-465e-825c-99712043e01c}"

Start-Sleep -Seconds 1
Write-Host "==========================================`n"
Start-Sleep -Seconds 1
Write-Host "`n Created GodMode Control Panel on Desktop!"
Write-Host " THANKS FOR CHOOSING SZMELC <3`n"